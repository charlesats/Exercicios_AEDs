#ifndef INTERFACE_H
#define INTERFACE_H

#include "interface.h"

void MSG_AEDS();
void MSG_MENU();

#endif
