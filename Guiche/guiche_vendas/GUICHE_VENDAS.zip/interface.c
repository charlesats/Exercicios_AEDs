#include "interface.h"

void MSG_AEDS()
{
    printf("\n\n\t  AAA	EEEEEEE	DDDDD    SSSSS	");
    printf("\n\t AAAAA	EEEEEEE	DDDDDD  SSSSSSS");
    printf("\n\tAA   AA	EE	DD   DD SS");
    printf("\n\tAAAAAAA	EEEEEEE	DD   DD SSSSSS");
    printf("\n\tAAAAAAA	EEEEEEE	DD   DD  SSSSSS");
    printf("\n\tAA   AA	EE	DD   DD      SS");
    printf("\n\tAA   AA	EEEEEEE	DDDDDD   SSSSSS");
    printf("\n\tAA   AA	EEEEEEE	DDDDD   SSSSSS");
    printf("\n\t                        GUICHE\n\n");
}
void MSG_MENU()
{
    printf("\n\n\t>>>>>>>>>>>>>>>>>>>    MENU:   <<<<<<<<<<<<<<<<<<<");
    printf("\n\t> 1. ENTRAR NA FILA                              <");
    printf("\n\t> 2. COMPRAR PASSAGEM                            <");
    printf("\n\t> 3. IMPRIMIR FILA DE ESPERA                     <");
    printf("\n\t> 4. MOSTRAR INFORMAÇÕES DA FILA                 <");
    printf("\n\t> 5. SAIR DA FILA                                <");
    printf("\n\t> 6. SAIR DO PROGRAMA                            <");
    printf("\n\t>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<");
}
