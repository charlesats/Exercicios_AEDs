#include "exercicios.h"
#include "amizade.h"

int MaisAmigos(TRedeSocial rede)
{
    int i, maior = 0, indiceMaisAmigos;

    for(i=0; i<rede.indice; i++)
    {
        if(rede.vetor[i].total_amigos > maior)
        {
            maior = rede.vetor[i].total_amigos;
            indiceMaisAmigos = i;
        }
    }

    if(maior > 0)
        return indiceMaisAmigos;
    return -1;
}

int AmigosEmComum(TRedeSocial rede, int id1, int id2)
{
    int i, qtd = 0;

    for(i=0; i< rede.indice; i++)
    {
        if((rede.matrix[id1][i] == 1) && (rede.matrix[id2][i] == 1))
            qtd++;
    }
    return qtd;
}

int AmizadeIndireta1(TRedeSocial rede, TUsuarios userA, TUsuarios userB)
{
    int i;

    for(i=0; i<rede.indice; i++)
    {
        if((rede.matrix[userA.ID][userB.ID]==0) && ((rede.matrix[userA.ID][i] == 1) && (rede.matrix[userB.ID][i] == 1)))
            return i;
        else
            return -1;
    }
    return -1;
}

void MatrizAmigosEmComum(TRedeSocial *rede)
{
    int linha, coluna;

    //Gerar a matriz de amizades em comum
    for(linha = 0; linha < rede->indice; linha++)
    {
        for(coluna = 0; coluna < rede->indice; coluna++)
        {
            if(linha != coluna)
                rede->matriz_amizades_em_comum[linha][coluna] = AmigosEmComum(*rede, linha, coluna);
        }
    }

    //Teste, imprime a matriz de amizades em comum
    /*for(linha = 0; linha < rede->indice; linha++)
    {
        printf("\n");
        for(coluna = 0; coluna < rede->indice; coluna++)
        {
            printf("%d ", rede->matriz_amizades_em_comum[linha][coluna]);
        }
    }
    printf("\n\n");*/
}

void SemAmigosEmComum(TRedeSocial rede, TUsuarios userA, TUsuarios userB)
{
    int i, j, k;

    i = Pesquisar(rede, userA);

    if(i>=0)
    {
        j = Pesquisar(rede, userB);
        if(j>=0)
        {
            k = PesquisarAmizades(rede, userA, userB);

            MatrizAmigosEmComum(&rede);

            if((k == 0) && (rede.matriz_amizades_em_comum[i][j] == 0))
            {
                printf("\n\n\t>>>>>>    MSG: Os usu�rios n�o possuem amigos em comum!    <<<<<<\n\n");
            }
            else
                printf("\n\n\t>>>>>>    MSG: Os usu�rios possuem %d amigos em comum!    <<<<<<\n\n", rede.matriz_amizades_em_comum[i][j]);
        }
    }
    else
        printf("\n\n\t>>>>>>    MSG: Os usu�rios n�o foram encontrados na rede!!!    <<<<<<\n\n");
}

void AmizadeIndireta2(TRedeSocial rede, TUsuarios userA, TUsuarios userB, int *id1, int *id2)
{
    //FUN��O N�O CONCLU�DA

    system("cls");
    printf("\n\n\t>>>>>>    MSG: FUN��O N�O CONCLU�DA!!!!    <<<<<<!!!!!");
    /*int i, j;

    for(i=0; i<rede.indice; i++)
    {
        for(j=0; j<rede.indice; j++)
        {

        }
    }
    */

}
